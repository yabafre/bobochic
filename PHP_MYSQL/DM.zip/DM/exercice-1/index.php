<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DM 1</title>
</head>
<body>
  <h1>DM 1</h1>

<?php 

  //Exercice 1
  //Récupérer les données envoyées en GET : ?nom=Dupont&prenom=Michel&age=20
  //Attention : faite bien les contrôles de vérification des champs s'ils sont bien saisies
  echo '<br>';

  //Exercice 2
  //Créer un formulaire qui prend exemple au lien suivant : https://arcanum.paris/user/new
  //Afficher les données saisies sur la page
  //Ne pas prendre en compte le champ des numéros indicatif téléphonique, civilité et du design

  //Attention : faite bien les contrôles de vérification des champs s'ils sont bien saisies

  // Mot de passe
  //   Faire au moins 8 caractères
  //   Avoir au moins 1 chiffre
  //   Avoir au moins une majuscule et une minuscule
  //Email
  //  Vérifier qu'il y a un '@' et '.fr, .com'
  //Telephone
  //  Vérifier qu'il n'y a que des chiffres
  //  Vérifier que la taille minimum maximum est 10 chiffres


?>
</body>
</html>